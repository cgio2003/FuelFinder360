import firebase_admin
import pandas as pd
from firebase_admin import credentials, messaging
import schedule
import time

# Inizializza Firebase Admin SDK
cred = credentials.Certificate(r"C:\Users\vitto\PycharmProjects\maps\fuelfinder360-firebase-adminsdk-hu75r-abe31f8151.json")
firebase_admin.initialize_app(cred)


# push notification
def send_notification(device_token):
    message = messaging.Message(
        notification=messaging.Notification(
            title="Fuel price",
            body="The fuel price in your favourite station has dropped below the desired value!",
        ),
        token=device_token,
    )

    # Invia la notifica
    response = messaging.send(message)
    print("Notifica inviata:", response)


def clean_coordinates(coord):
    """Converts coordinates to float, handling non-numeric and corrupted data."""
    try:
        return float(coord)
    except ValueError:
        return pd.NA  # Using pandas NA to handle missing data appropriately.


def monitor_gas_prices(selected_fuel='Benzina', selected_latitude=None, selected_longitude=None):
    # Load data
    df_prices = pd.read_csv(r'C:\Users\vitto\PycharmProjects\maps\urlprices.csv', delimiter=';', encoding='utf-8', on_bad_lines='warn')
    df_stations = pd.read_csv(r'C:\Users\vitto\PycharmProjects\maps\urlstations.csv', delimiter=';', encoding='utf-8', on_bad_lines='warn')

    # Merge dataframes on 'idImpianto'
    merged_data = pd.merge(df_prices, df_stations, on='idImpianto', how='inner')

    # Clean and convert latitude and longitude
    merged_data['Latitudine'] = merged_data['Latitudine'].apply(clean_coordinates)
    merged_data['Longitudine'] = merged_data['Longitudine'].apply(clean_coordinates)
    merged_data.dropna(subset=['Latitudine', 'Longitudine'], inplace=True)

    # Filter data for selected fuel type
    selected_data = merged_data[merged_data['descCarburante', 'Latitudine', 'Longitudine'] == selected_fuel, selected_latitude, selected_longitude]
    return selected_data['Prezzo']


def job(selected_fuel, selected_latitude, selected_longitude):
    fuel_price = monitor_gas_prices(selected_fuel, selected_latitude, selected_longitude)
    print(f"Prezzo di {selected_fuel}: {fuel_price}")
    # if fuel_price <= chosen_price:
        # send_notification()


def main():
    selected_fuel = 'Benzina'
    # device_token = ... (from swift)
    chosen_price = 1.9 # (from swift)
    selected_latitude = 37.7749 # just an example (then taken from the device location)
    selected_longitude = -122.4194 # just an example (then taken from the device location)

    schedule.every().day.at("08:30").do(job(selected_fuel, selected_latitude, selected_longitude))
    while True:
        schedule.run_pending()
        time.sleep(60)  # Decide every minute if it is time to do the job


if __name__ == '__main__':
    main()


