from flask import Flask, request, jsonify
import pandas as pd
import googlemaps
import geopandas as gpd
from shapely.geometry import Point


app = Flask(__name__)
# Initialize Google Maps client
gmaps = googlemaps.Client(key='AIzaSyD-zfQbleW8HwuG6P_BOvH-XQL5BZC9Of0')


# Definizione di latitude e longitude come variabili globali
latitude = None
longitude = None
first_station = None

@app.route('/update_location', methods=['POST'])
def update_location():
    global latitude, longitude
    data = request.get_json()  # This must be inside a function
    latitude = data.get('latitude')
    longitude = data.get('longitude')
    print(latitude)
    process_data()
    return jsonify({"latitude": latitude, "longitude": longitude, "message": "Location updated successfully"}), 200


@app.route('/get_station_coordinates', methods=['GET'])
def get_station_coordinates():
    global first_station
    print(first_station)
    if first_station is not None:
        response = {
            'latitude': first_station['Latitudine'],
            'longitude': first_station['Longitudine']
        }
        return jsonify(response), 200
    else:
        return jsonify({'error': 'No station coordinates available'}), 404

def clean_coordinates(coord):
    """Converts coordinates to float, handling non-numeric and corrupted data."""
    try:
        return float(coord)
    except ValueError:
        return pd.NA  # Using pandas NA to handle missing data appropriately.


def calculate_distance(row, my_location_coords):
    try:
        station_location = (row.geometry.y, row.geometry.x)
        distance_result = gmaps.distance_matrix(my_location_coords, station_location, mode="driving")

        if distance_result['status'] == 'OK':
            element = distance_result['rows'][0]['elements'][0]
            if element['status'] == 'OK':
                return element['distance']['value'] / 1000  # Convert meters to kilometers
            else:
                print(f"API Element Error for station {row['idImpianto']}: {element['status']}")
                return float('inf')  # Use infinity to denote unreachable locations
        else:
            print(f"API Response Error for station {row['idImpianto']}: {distance_result['status']}")
            return float('inf')
    except Exception as e:
        print(f"Exception during API call for station {row['idImpianto']}: {e}")
        return float('inf')
    # Esempio di utilizzo della funzione

def process_data():
    global first_station
    if latitude is not None and longitude is not None:
        print(f"Coordinate lette correttamente: Latitudine = {latitude}, Longitudine = {longitude}")
    else:
        print("Errore durante la lettura delle coordinate da file")

    # Coordinates for the desired location (e.g., Turin)
    my_location_coords = (latitude, longitude)

    # Load data
    df_prices = pd.read_csv(r'/Users/giovanni/PycharmProjects/DataTransfer/urlprices.csv', delimiter=';', encoding='utf-8', on_bad_lines='warn')
    df_stations = pd.read_csv(r'/Users/giovanni/PycharmProjects/DataTransfer/urlstations.csv', delimiter=';', encoding='utf-8', on_bad_lines='warn')

    # Merge dataframes on 'idImpianto'
    merged_data = pd.merge(df_prices, df_stations, on='idImpianto', how='inner')

    # Clean and convert latitude and longitude
    merged_data['Latitudine'] = merged_data['Latitudine'].apply(clean_coordinates)
    merged_data['Longitudine'] = merged_data['Longitudine'].apply(clean_coordinates)
    merged_data.dropna(subset=['Latitudine', 'Longitudine'], inplace=True)

    # Convert to GeoDataFrame and set CRS
    gdf = gpd.GeoDataFrame(merged_data, geometry=gpd.points_from_xy(merged_data.Longitudine, merged_data.Latitudine))
    gdf.set_crs("EPSG:4326", inplace=True)  # Set CRS to WGS84

    # Define location with buffer
    my_location = gpd.GeoDataFrame(geometry=[Point(my_location_coords[1], my_location_coords[0])], crs="EPSG:4326")
    buffer = my_location.to_crs(epsg=3857).buffer(5000)  # 10 km buffer in meters
    my_location = my_location.to_crs(epsg=3857)  # Consistent CRS for distance calculations

    # Filter stations within the buffer
    nearby_stations = gdf[gdf.to_crs(epsg=3857).within(buffer.unary_union)]
    nearby_stations = nearby_stations[(nearby_stations['descCarburante'] == 'Benzina')]
    # print("Nearby stations count after buffer:", nearby_stations.shape[0])

    # Apply the distance calculation
    nearby_stations['Distanza'] = nearby_stations.apply(lambda x: calculate_distance(x, my_location_coords), axis=1)
    # print("Distances calculated:")
    # print(nearby_stations[['idImpianto', 'Distanza']].head())

    # Sort by price and distance
    sorted_stations = nearby_stations.sort_values(by=['Distanza'])
    # print("Sorted Stations by Price and Distance:")
    # print(sorted_stations[['idImpianto', 'Gestore', 'prezzo', 'Distanza']].head())
    global first_station
    # Ottieni il primo elemento dalla DataFrame `sorted_stations` con le colonne 'Nome', 'Latitudine' e 'Longitudine'
    first_station = sorted_stations[['idImpianto', 'Latitudine', 'Longitudine']].iloc[0]

    # Assegna first_station a una variabile globale


    # Stampalo per verificarlo
    print(first_station)


if __name__ == '__main__':
    app.run("0.0.0.0", 5010, debug=True)
