import csv
from io import StringIO
import requests
import schedule
import time

def job():
    NUMERO_COLONNE_ATTESO = 10

    # URL file CSV
    url_csvprices = 'https://www.mimit.gov.it/images/exportCSV/anagrafica_impianti_attivi.csv'

    # output file
    output_csv_pathprices = r'C:\Users\vitto\PycharmProjects\maps\urlprices.csv'

    # Usa requests to obtain the data of the URL
    response1 = requests.get(url_csvprices)
    response1.raise_for_status()  # Verify if request was completed

    file_like1 = StringIO(response1.text)

    # Processa il contenuto CSV
    with open(output_csv_pathprices, mode='w', newline='', encoding='utf-8') as outfile:
        reader = csv.reader(file_like1, delimiter=';')
        writer = csv.writer(outfile, delimiter=';')
        next(reader)
        for row in reader:
            if len(row) == NUMERO_COLONNE_ATTESO:
                writer.writerow(row)
            else:
                writer.writerow(row[:NUMERO_COLONNE_ATTESO])

        print("File scritto con successo con solo le righe corrette.")

    # URL del file CSV
    url_csvstations = r'https://www.mimit.gov.it/images/exportCSV/prezzo_alle_8.csv'

    # Percorso del file di output
    output_csv_pathstations = r'C:\Users\vitto\PycharmProjects\maps\urlstations.csv'

    # Usa requests per ottenere i dati dal URL
    response2 = requests.get(url_csvstations)
    response2.raise_for_status()  # Verifica che la richiesta sia andata a buon fine

    # Usa StringIO per simulare un file letto dalla risposta
    file_like2 = StringIO(response2.text)

    # Processa il contenuto CSV
    with open(output_csv_pathstations, mode='w', newline='', encoding='utf-8') as outfile:
        reader = csv.reader(file_like2, delimiter=';')
        writer = csv.writer(outfile, delimiter=';')
        next(reader)
        for row in reader:
            # Scrivi solo le righe che hanno il numero corretto di colonne
            if len(row) == NUMERO_COLONNE_ATTESO:
                writer.writerow(row)
            else:
                # Opzionale: puoi anche decidere di tagliare le colonne extra
                writer.writerow(row[:NUMERO_COLONNE_ATTESO])

    print("Aggiornando i dati...")


def main():
    # Plan the execution of the script everyday
    schedule.every().day.at("08:10").do(job)

    while True:
        schedule.run_pending()
        time.sleep(60)


if __name__ == '__main__':
    main()
