import pandas as pd
import geopandas as gpd
from shapely.geometry import Point, LineString
import googlemaps
from datetime import datetime
import matplotlib.pyplot as plt
import numpy as np
from flask import Flask, request, jsonify

# sarebbe bello mostrare la cartina con le fermate stabilite
app = Flask(__name__)
# Initialize Google Maps API client
API_KEY = 'AIzaSyD-zfQbleW8HwuG6P_BOvH-XQL5BZC9Of0'
gmaps = googlemaps.Client(key=API_KEY)


# Definizione di latitude e longitude come variabili globali
startlongitude = None
startlatitude = None
endlongitude = None
endlatitude = None
current_fuel = None
fuel_efficiency = None
max_fuel_capacity = None
type_fuel = None

best_stations = []
calculation_completed = False


@app.route('/calculate_route', methods=['POST'])
def calculate_route():
    data = request.get_json()
    main(data)
    return jsonify({'status': 'Route calculation completed', 'number_of_stations': len(best_stations)}), 200


@app.route('/get_all_stations', methods=['GET'])
def get_all_stations():
    response = [{'index': idx, 'name': station['Gestore'], 'latitude': station['Latitudine'], 'longitude': station['Longitudine'], 'price': str(station['prezzo']), 'comune': station['Comune'], 'province': station['Provincia']} for idx, station in enumerate(best_stations)]
    return jsonify({'stations': response, 'completed': calculation_completed}), 200


@app.route('/get_station_coordinates/<int:station_index>', methods=['GET'])
def get_station_coordinates(station_index):
    if 0 <= station_index < len(best_stations):
        station = best_stations[station_index]
        response = {
            'latitude': station['Latitudine'],
            'longitude': station['Longitudine'],
            'price': str(station['prezzo']),
            'comune': station['Comune'],
            'provincia': station['Provincia']
        }
        return jsonify(response), 200
    else:
        return jsonify({'error': 'Station index out of range'}), 404


def clean_coordinates(coord):
    try:
        return float(coord)
    except ValueError:
        return None  # Return None for failed conversions


def load_and_merge_data(price_file, station_file):
    df_prices = pd.read_csv(price_file, delimiter=';', encoding='utf-8', on_bad_lines='skip')
    df_stations = pd.read_csv(station_file, delimiter=';', encoding='utf-8', on_bad_lines='skip')
    merged_data = pd.merge(df_prices, df_stations, on='idImpianto', how='inner')
    merged_data['Latitudine'] = merged_data['Latitudine'].apply(clean_coordinates)
    merged_data['Longitudine'] = merged_data['Longitudine'].apply(clean_coordinates)
    merged_data.dropna(subset=['Latitudine', 'Longitudine'], inplace=True)
    return merged_data


def create_geodataframe(merged_data):
    merged_data['geometry'] = merged_data.apply(lambda row: Point(row['Longitudine'], row['Latitudine']), axis=1)
    gdf = gpd.GeoDataFrame(merged_data, geometry='geometry')
    gdf.set_crs('EPSG:4326', inplace=True)
    return gdf


def get_directions(start, end):
    now = datetime.now()
    directions_result = gmaps.directions(start, end, mode="driving", departure_time=now)
    polyline = directions_result[0]['overview_polyline']['points']
    points = googlemaps.convert.decode_polyline(polyline)
    return [(point['lng'], point['lat']) for point in points]


def find_stations_near_route(gdf, path_points, max_distance=5):  # max_distance in kilometers
    line = LineString(path_points)
    gdf = gdf.to_crs(epsg=3857)
    line_projected = gpd.GeoSeries([line], crs='EPSG:4326').to_crs(epsg=3857).iloc[0]
    print(line_projected)
    print(max_distance)
    gdf['distance_to_route'] = gdf['geometry'].apply(lambda x: line_projected.distance(x)/1000)  # Convert meters to kilometers
    nearby_stations = gdf[gdf['distance_to_route'] <= max_distance]
    print("Number of stations found:", len(nearby_stations))
    return nearby_stations.to_crs('EPSG:4326')


@app.route('/post_trip_data', methods=['POST'])
def update_location():
    global startlongitude, startlatitude, endlongitude, endlatitude, current_fuel, fuel_efficiency, max_fuel_capacity, type_fuel
    data = request.get_json()  # This must be inside a function
    print(data)
    startlongitude = data.get('startLongitude')
    startlatitude = data.get('startLatitude')
    endlongitude = data.get('destinationLongitude')
    endlatitude = data.get('destinationLatitude')
    current_fuel = data.get('currentFuel')
    fuel_efficiency = data.get('averageConsumption')
    max_fuel_capacity = data.get('maxFuelCapacity')
    type_fuel = data.get('fuelType')
    if type_fuel == 'Petrol':
        type_fuel = 'Benzina'
    elif type_fuel == 'Diesel':
        type_fuel = 'Gasolio'
    elif type_fuel == 'Gas':
        type_fuel = 'Metano'
    fuel_efficiency = 1/fuel_efficiency
    main()
    return jsonify({"startlongitude": startlongitude, "startlatitude": startlatitude, "endlongitude": endlongitude, "endlatitude": endlatitude, "current_fuel": current_fuel, "fuel_efficiency": fuel_efficiency, "max_fuel_capacity": max_fuel_capacity, "type_fuel": type_fuel, "message": "Location updated successfully"}), 200


def calculate_refuel_stops(gdf, current_fuel, fuel_efficiency, max_fuel_capacity, path_points, chosen_price, max_distance=10):
    # Assicurati di lavorare su una copia del GeoDataFrame
    gdf = gdf.copy()

    # Converti il GeoDataFrame in un sistema di coordinate cartesiano (EPSG 32632)
    gdf = gdf.to_crs(epsg=32632)

    # Crea una LineString dal percorso dei punti forniti
    line = LineString(path_points)

    # Proietta la LineString su EPSG 32632
    line_gdf = gpd.GeoSeries([line], crs='EPSG:4326').to_crs(epsg=32632)

    # Seleziona la LineString proiettata
    line_projected = line_gdf.iloc[0]

    # Calcola la distanza cumulativa lungo la LineString proiettata
    segments = [LineString([line_projected.coords[i], line_projected.coords[i + 1]]) for i in range(len(line_projected.coords) - 1)]
    cumulative_lengths = np.cumsum([seg.length for seg in segments])

    # Definisci una funzione per calcolare la distanza cumulativa da un punto sulla LineString proiettata
    def get_cumulative_distance(point):
        distances = [seg.distance(point) for seg in segments]
        nearest_segment_index = np.argmin(distances)
        return (cumulative_lengths[nearest_segment_index] if nearest_segment_index > 0 else 0) / 1000  # Convert to km

    # Calcola la distanza tra ciascuna stazione di servizio e la LineString proiettata
    gdf['distance_to_route'] = gdf.geometry.apply(lambda x: line_projected.distance(x) / 1000)

    # Calcola la distanza cumulativa di ciascuna stazione di servizio rispetto al punto di partenza
    gdf['cumulative_distance'] = gdf.geometry.apply(get_cumulative_distance)


    # Calcola la massima distanza raggiungibile con il carburante attuale
    max_reachable_distance = current_fuel / fuel_efficiency
    print(f"The max distance is {max_reachable_distance}")

    # Seleziona le stazioni di servizio raggiungibili entro una certa distanza massima dal percorso
    reachable_stations = gdf[(gdf['distance_to_route'] <= max_distance) & (gdf['cumulative_distance'] <= max_reachable_distance)]

    # Effettua una copia delle stazioni raggiungibili per evitare modifiche al DataFrame originale
    reachable_stations = reachable_stations.copy()

    # Calcola il carburante necessario per raggiungere ciascuna stazione raggiungibile
    reachable_stations['fuel_needed'] = reachable_stations['cumulative_distance'] * fuel_efficiency

    # Seleziona le stazioni che possono essere raggiunte senza superare la capacità massima del serbatoio
    final_stations = reachable_stations[(reachable_stations['fuel_needed'] <= current_fuel) & (reachable_stations['prezzo'] <= chosen_price)]

    # Se non ci sono stazioni che possono essere raggiunte senza superare la capacità massima del serbatoio, restituisci None
    if final_stations.empty:
        return None

    # Trova la stazione più lontana ma ancora raggiungibile con il carburante attuale
    final_station = final_stations.sort_values(by=['cumulative_distance', 'prezzo'], ascending=[False, True]).head(1)

    # Restituisci la stazione selezionata con le coordinate proiettate su EPSG 4326
    return final_station.to_crs('EPSG:4326')




def plot_route_and_stations(gdf, path_points, nearby_stations, refuel_stations=None):
    fig, ax = plt.subplots(figsize=(15, 15))
    gdf = gdf.to_crs(epsg=3857)
    nearby_stations = nearby_stations.to_crs(epsg=3857)
    if refuel_stations is not None:
        refuel_stations = refuel_stations.to_crs(epsg=3857)
    gdf.plot(ax=ax, marker='o', color='blue', markersize=5, label='All Gas Stations')
    nearby_stations.plot(ax=ax, marker='^', color='green', markersize=10, label='Nearby Route Stations')
    if refuel_stations is not None and not refuel_stations.empty:
        refuel_stations.plot(ax=ax, marker='*', color='gold', markersize=15, label='Refuel Stops')
    route_line = LineString(path_points)
    route_gdf = gpd.GeoSeries([route_line], crs='EPSG:4326').to_crs(epsg=3857)
    route_gdf.plot(ax=ax, color='red', linewidth=2, label='Route')
    ax.set_aspect('equal')
    plt.legend()
    plt.title('Route with Gas Stations')
    plt.xlabel('Longitude')
    plt.ylabel('Latitude')
    plt.grid(True)
    plt.show()



def main():
    global startlongitude, startlatitude, endlongitude, endlatitude, current_fuel, fuel_efficiency, max_fuel_capacity, type_fuel, calculation_completed
    # start = (40.851775, 14.268124)  # Coordinates for Naples
    # end = (45.464204, 9.189982)   # Coordinates for Milan
    # current_fuel = 5  # liters remaining
    # fuel_efficiency = 0.06  # liters per km
    # max_fuel_capacity = 20  # maximum tank capacity in liters
    reached = False
    chosen_price = 2
    calculation_completed = False

    merged_data = load_and_merge_data('urlprices.csv', 'urlstations.csv')
    gdf = create_geodataframe(merged_data)

    while not reached:
        path_points = get_directions((startlatitude, startlongitude), (endlatitude, endlongitude))  # Get directions from current start to Milan
        nearby_stations = find_stations_near_route(gdf, path_points, 10)  # Find stations within 10 km of the route
        nearby_stations = nearby_stations[nearby_stations['descCarburante'] == type_fuel]

        if nearby_stations.empty:
            print("No more stations found nearby, cannot continue the journey.")
            break

        refuel_stations = calculate_refuel_stops(nearby_stations, current_fuel, fuel_efficiency, max_fuel_capacity, path_points, chosen_price, 10)
        if refuel_stations.empty:
            print("No reachable refuel stations found, cannot continue the journey.")
            break

        best_station = refuel_stations.iloc[0].copy()  # Assuming the first one is the best after sorting
        print("Best Refuel Station:")
        print(best_station[['idImpianto', 'Gestore', 'prezzo', 'geometry', 'fuel_needed']])

        best_stations.append({
            'idImpianto': best_station['idImpianto'],
            'Gestore': best_station['Gestore'],
            'prezzo': best_station['prezzo'],
            'Latitudine': best_station['geometry'].y,
            'Longitudine': best_station['geometry'].x,
            'Comune': best_station['Comune'],
            'Provincia': best_station['Provincia']
        })

        # Update start to the location of the best refuel station
        (startlatitude, startlongitude) = (best_station['geometry'].y.copy(), best_station['geometry'].x.copy())
        # current_fuel = max_fuel_capacity - best_station['fuel_needed']  # Assume full refuel minus fuel needed to reach
        current_fuel = max_fuel_capacity

        # Calculate distance from current station to Milan
        destination_point = Point(endlongitude, endlatitude)
        station_point = Point(best_station['geometry'].x.copy(), best_station['geometry'].y.copy())
        remaining_distance = destination_point.distance(station_point) * 111.32  # Convert degrees to kilometers

        print(f"Distance from current station to Milan: {remaining_distance:.2f} km")

        if remaining_distance <= (current_fuel / fuel_efficiency):
            print("Destination is within reach with the current fuel.")
            reached = True
    calculation_completed = True

    # Plot the route and stations
    # plot_route_and_stations(gdf, path_points, nearby_stations, refuel_stations)


if __name__ == '__main__':
    app.run('0.0.0.0', 5030, debug=True)
